package bus.ticket.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import bus.ticket.entities.*;
import bus.ticket.model.*;
import bus.ticket.service.*;

import java.util.*;

@RestController
public class AppuserController {

    @Autowired
    private AppuserService aus;


    @GetMapping("/getAnUser{id}")
    public AppuserDTO getUserById(@PathVariable Long id) {
        return aus.getUserById(id);
    }

    @GetMapping("/getAllUsers")
    public List<AppuserDTO> getAllUsers() {
        return aus.getAllUsers();
    }

    @PostMapping("/createUser")
    public AppuserDTO createUser(@RequestBody Appuser appuser) {
        return aus.createUser(appuser);
    }

    @PutMapping("/updateUser{id}")
    public AppuserDTO updateUser(@PathVariable Long id, @RequestBody Appuser appuser) {
        return aus.updateUser(id, appuser);
    }

    @DeleteMapping("/deleteUser{id}")
    public String deleteUser(@PathVariable Long id) {
        return aus.deleteUser(id);
    }

}



