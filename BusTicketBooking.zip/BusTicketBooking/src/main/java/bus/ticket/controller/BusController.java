package bus.ticket.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import bus.ticket.entities.*;
import bus.ticket.model.*;
import bus.ticket.service.*;

import java.util.*;

@RestController
public class BusController {

    @Autowired
    private BusService busService;

    @GetMapping("/getBusById/{id}")
    public BusDTO getBusById(@PathVariable Long id) {
        return busService.getBusById(id);
    }

    @GetMapping("/getAllBuses")
    public List<BusDTO> getAllBuses() {
        return busService.getAllBuses();
    }

    @PostMapping("/createBus")
    public BusDTO createBus(@RequestBody Bus bus) {
        return busService.createBus(bus);
    }

    @PutMapping("/updateBus/{id}")
    public BusDTO updateBus(@PathVariable Long id, @RequestBody Bus bus) {
        return busService.updateBus(id, bus);
    }

    @DeleteMapping("/deleteBus/{id}")
    public String deleteBus(@PathVariable Long id) {
        return busService.deleteBus(id);
    }
    
    @PutMapping("/assignBus/{busid}/{scheduleid}/{routeid}")
    public String assignBus(@PathVariable("busid") long busid,  @PathVariable("scheduleid") long scheduleid,  @PathVariable("routeid") long routeid) {
    	return busService.assignBus(busid, scheduleid, routeid);
    }
}

