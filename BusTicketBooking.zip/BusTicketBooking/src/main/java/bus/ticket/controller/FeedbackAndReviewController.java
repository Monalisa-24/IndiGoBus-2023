package bus.ticket.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import bus.ticket.entities.*;
import bus.ticket.model.*;
import bus.ticket.service.*;

import java.util.*;

@RestController
@RequestMapping("/reviews")
public class FeedbackAndReviewController {

    @Autowired
    private FeedbackAndReviewService feedbackAndReviewService;

    @PostMapping("/submitReview")
    public FeedbackAndReviewDTO submitFeedbackAndReview(@RequestBody FeedbackAndReview review, @RequestParam Long appuserid) {
        return feedbackAndReviewService.submitFeedbackAndReview(review, appuserid);
    }

    @GetMapping("/getAllReviews")
    public List<FeedbackAndReviewDTO> getAllReviews() {
        return feedbackAndReviewService.getAllReviews();
    }

    @GetMapping("/getReviewsByUser/{appuserid}")
    public List<FeedbackAndReviewDTO> getReviewsByUser(@PathVariable Long appuserid) throws Exception {
        return feedbackAndReviewService.getReviewsByUser(appuserid);
    }

//    @GetMapping("/getRecentReviews/{count}")
//    public List<FeedbackAndReviewDTO> getRecentReviews(@PathVariable int count) throws Exception {
//        return feedbackAndReviewService.getRecentReviews(count);
//    }

    @DeleteMapping("/deleteReview{reviewId}")
    public String deleteReview(@PathVariable Long reviewId, @RequestParam Long appuserid) {
        return feedbackAndReviewService.deleteReview(reviewId, appuserid);
    }

    @PutMapping("/updateReview{reviewId}")
    public FeedbackAndReviewDTO updateReview(@PathVariable Long reviewId, @RequestBody FeedbackAndReview updatedReview) {
        return feedbackAndReviewService.updateReview(reviewId, updatedReview);
    }
}
