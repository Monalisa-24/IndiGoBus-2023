package bus.ticket.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import bus.ticket.entities.*;
import bus.ticket.model.*;
import bus.ticket.service.*;

import java.util.*;

@RestController
public class RouteController {

    @Autowired
    private RouteService routeService;

    @GetMapping("/getARoute{id}")
    public RouteDTO getRouteById(@PathVariable Long id) {
        return routeService.getRouteById(id);
    }

    @GetMapping("/getAllroutes")
    public List<RouteDTO> getAllRoutes() {
        return routeService.getAllRoutes();
    }

    @PostMapping("/createRoutes")
    public RouteDTO createRoute(@RequestBody Route route) {
        return routeService.createRoute(route);
    }

    @PutMapping("/updateRoute{id}")
    public RouteDTO updateRoute(@PathVariable Long id, @RequestBody Route route) {
        return routeService.updateRoute(id, route);
    }

    @DeleteMapping("/deleteRoute{id}")
    public String deleteRoute(@PathVariable Long id) {
        return routeService.deleteRoute(id);
    }
}
