package bus.ticket.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import bus.ticket.entities.*;
import bus.ticket.model.*;
import bus.ticket.service.*;

import java.util.*;

@RestController
public class ScheduleController {

    @Autowired
    private ScheduleService scheduleService;

    @GetMapping("/getASchedule{id}")
    public ScheduleDTO getScheduleById(@PathVariable Long id) {
        return scheduleService.getScheduleById(id);
    }

    @GetMapping("/getAllAchedules")
    public List<ScheduleDTO> getAllSchedules() {
        return scheduleService.getAllSchedules();
    }

    @PostMapping("/createSchedule")
    public ScheduleDTO createSchedule(@RequestBody Schedule schedule) {
        return scheduleService.createSchedule(schedule);
    }

    @PutMapping("/updateSchedule{id}")
    public ScheduleDTO updateSchedule(@PathVariable Long id, @RequestBody Schedule schedule) {
        return scheduleService.updateSchedule(id, schedule);
    }

    @DeleteMapping("/deleteSchedule{id}")
    public String deleteSchedule(@PathVariable Long id) {
        return scheduleService.deleteSchedule(id);
    }
}
