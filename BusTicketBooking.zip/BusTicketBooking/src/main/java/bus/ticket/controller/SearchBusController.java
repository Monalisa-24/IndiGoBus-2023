package bus.ticket.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import bus.ticket.entities.*;
import bus.ticket.exception.NotAvailableException;
import bus.ticket.model.RouteDTO;
import bus.ticket.model.ScheduleDTO;
import bus.ticket.repository.*;
import bus.ticket.service.*;
import bus.ticket.util.Converter;

@RestController
public class SearchBusController {

	
	@Autowired
	BusService bservice;
	@Autowired
	RouteService rservice;
	@Autowired
	ScheduleService sservice;
	@Autowired
	Converter con;
	
	@GetMapping("/searchBus")
    public List<Bus> searchBusesByRouteAndSchedule(
            @RequestParam Long routeId,
            @RequestParam Long scheduleId) {
        RouteDTO route = rservice.getRouteById(routeId);
        ScheduleDTO schedule = sservice.getScheduleById(scheduleId);

        if (route != null && schedule != null) {
            return bservice.findBusesByRouteAndSchedule(route, schedule);
        } else {
            throw new NotAvailableException("No bus available.");
        }
		
    }
	
	
	
}
