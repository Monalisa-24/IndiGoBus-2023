package bus.ticket.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import bus.ticket.entities.*;
import bus.ticket.model.BusDTO;
import bus.ticket.model.TicketDTO;
import bus.ticket.repository.TicketRepository;
import bus.ticket.service.*;

@RestController
public class TicketController {
	@Autowired
	TicketService ticketservice;
	@Autowired
	AppuserService appuserservice;
	@Autowired
	BusService busservice;
	
	@PutMapping("/bookTicket/{appuserid}/{busid}/{ticketid}")
    public String bookTicket(@PathVariable("appuserid") long appuserid,@PathVariable("busid") long busid,@PathVariable("ticketid") long ticketid) {
        return ticketservice.bookTicket(appuserid, busid, ticketid);
    }
	
	@PostMapping("/createTicket")
	public TicketDTO createTicket(@RequestBody Ticket ticket) {
		return ticketservice.createTicket(ticket);
	}
	
	@GetMapping("/getTicketOfUser/{appuserid}")
	List<TicketDTO> getAllTicketsForUser(@PathVariable long appuserid){
		return ticketservice.getAllTicketsForUser(appuserid);
	}
	
	@GetMapping("/getTicketOfBus/{bus}")
	List<TicketDTO> getAllTicketsForBus(@PathVariable long busid){
		return ticketservice.getAllTicketsForBus(busid);
	}
	
	@GetMapping("/getTicketById/{ticketid}")
    public TicketDTO getTicketById(@PathVariable Long ticketid) {
        return ticketservice.getTicketById(ticketid);
    }

    @GetMapping("/getAllTickets")
    public List<TicketDTO> getAllTickets() {
        return ticketservice.getAllTickets();
    }
}
