package bus.ticket.entities;

import javax.persistence.*;

@Entity
@Table(name = "appuser")
public class Appuser {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long appuserid;
	@Column(unique=true)
    private String username;
    private String password;
    @Column(unique=true)
    private String email;
//    @OneToOne(cascade = CascadeType.ALL, mappedBy = "appuser")
//    private VerificationToken verificationToken;

    // Getter and setter for verificationToken

//    public VerificationToken getVerificationToken() {
//        return verificationToken;
//    }
//
//    public void setVerificationToken(VerificationToken verificationToken) {
//        this.verificationToken = verificationToken;
//    }
    
    
	public Long getUserid() {
		return appuserid;
	}
	public void setUserId(Long appuserid) {
		this.appuserid = appuserid;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	


	
	@Override
	public String toString() {
		return "Appuser [userId=" + appuserid + ", username=" + username + ", password=" + password + ", email=" + email+ "]";
	}
    
}
