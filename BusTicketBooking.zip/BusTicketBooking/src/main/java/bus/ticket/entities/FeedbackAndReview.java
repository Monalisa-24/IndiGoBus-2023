package bus.ticket.entities;


import javax.persistence.*;

@Entity
@Table(name = "feedback_and_review")
public class FeedbackAndReview {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long reviewid;

    @ManyToOne
    @JoinColumn(name = "appuserid")
    private Appuser appuser;


    private String reviewText;
    private int rating;
    
    
	public Long getReviewId() {
		return reviewid;
	}
	public void setReviewId(Long reviewid) {
		this.reviewid = reviewid;
	}
	public Appuser getAppuser() {
		return appuser;
	}
	public void setAppuser(Appuser appuser) {
		this.appuser = appuser;
	}
	
	public String getReviewText() {
		return reviewText;
	}
	public void setReviewText(String reviewText) {
		this.reviewText = reviewText;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "FeedbackAndReview [reviewId=" + reviewid + ", appuser=" + appuser + ", reviewText="
				+ reviewText + ", rating=" + rating + "]";
	}
}
