package bus.ticket.entities;

import java.sql.Timestamp;

import javax.persistence.*;

@Entity
@Table(name = "payment")
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long paymentid;

    @ManyToOne
    @JoinColumn(name = "appuserid")
    private Appuser appuser;
    
    @ManyToOne
    @JoinColumn(name = "ticketid")
    private Ticket ticket;
    
    private double amount;
    private Timestamp timestamp;
    
	public Long getPaymentid() {
		return paymentid;
	}
	public void setPaymentid(Long paymentid) {
		this.paymentid = paymentid;
	}
	public Appuser getAppuser() {
		return appuser;
	}
	public void setAppuser(Appuser appuser) {
		this.appuser = appuser;
	}
	
	public Ticket getTicket() {
		return ticket;
	}
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Timestamp getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}
	
	
	@Override
	public String toString() {
		return "Payment [paymentid=" + paymentid + ", appuser=" + appuser + ", ticket=" + ticket + ", amount=" + amount
				+ ", timestamp=" + timestamp + "]";
	}
}
