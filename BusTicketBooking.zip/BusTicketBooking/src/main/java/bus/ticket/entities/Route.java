package bus.ticket.entities;

import javax.persistence.*;


@Entity
@Table(name = "route")
public class Route {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long routeid;
    private String routeName;
    private String origin;
    private String destination;
    
    public Route(String routeName) {
        this.routeName = routeName;
    }
    
    
	


	public Route() {
		super();
		// TODO Auto-generated constructor stub
	}





	public String getRouteName() {
		return routeName;
	}

	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}

	public void setRouteid(Long routeid) {
		this.routeid = routeid;
	}

	public Long getRouteid() {
		return routeid;
	}
	
	
	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}


	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}





	@Override
	public String toString() {
		return "Route [routeid=" + routeid + ", routeName=" + routeName + ", origin=" + origin + ", destination="
				+ destination + "]";
	}
	
}

