package bus.ticket.entities;


import java.time.LocalTime;

import javax.persistence.*;


@Entity
@Table(name = "schedule")
public class Schedule {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long scheduleid;
    private String scheduleName;
    private LocalTime departureTime;
    private LocalTime arrivalTime;
    
    public Schedule(String scheduleName) {
        this.scheduleName = scheduleName;
    }
    
	public Schedule() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Long getScheduleid() {
		return scheduleid;
	}

	public void setScheduleid(Long scheduleid) {
		this.scheduleid = scheduleid;
	}

	public String getScheduleName() {
		return scheduleName;
	}

	public void setScheduleName(String scheduleName) {
		this.scheduleName = scheduleName;
	}

	
	public LocalTime getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(LocalTime departureTime) {
		this.departureTime = departureTime;
	}
	public LocalTime getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(LocalTime arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	
	
	@Override
	public String toString() {
		return "Schedule [scheduleid=" + scheduleid + ", scheduleName=" + scheduleName + ", departureTime="
				+ departureTime + ", arrivalTime=" + arrivalTime + "]";
	}
}

