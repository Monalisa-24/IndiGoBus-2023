package bus.ticket.entities;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "ticket")
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ticketid")
    private Long ticketid;
    @ManyToOne
    @JoinColumn(name = "userid")
    private Appuser appuser;
    @ManyToOne
    @JoinColumn(name = "busid")
    private Bus bus;
    @Column(name = "bookingDate")
    private Timestamp bookingDate;
//    private boolean isAvailable = true;
    
    public Ticket() {
        this.bookingDate = new Timestamp(new Date().getTime());
    }
    
	public Long getTicketid() {
		return ticketid;
	}
	public void setTicketid(Long ticketid) {
		this.ticketid = ticketid;
	}
	public Appuser getAppuser() {
		return appuser;
	}
	public void setAppuser(Appuser appuser) {
		this.appuser = appuser;
	}
	public Bus getBus() {
		return bus;
	}
	public void setBus(Bus bus) {
		this.bus = bus;
	}
	public Timestamp getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(Timestamp bookingDate) {
		this.bookingDate = bookingDate;
	}
	
	

	
	@Override
	public String toString() {
		return "Ticket [ticketid=" + ticketid + ", appuser=" + appuser + ", bus=" + bus + ", bookingDate=" + bookingDate + "]";
	}
}

