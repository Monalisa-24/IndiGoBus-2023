package bus.ticket.exception;

public class NotAvailableException extends RuntimeException {

    public NotAvailableException(String message) {
        super(message);
    }
}
