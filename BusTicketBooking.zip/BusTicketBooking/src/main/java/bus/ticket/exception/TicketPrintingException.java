package bus.ticket.exception;

import java.io.IOException;

public class TicketPrintingException extends RuntimeException {
	public TicketPrintingException(String message) {
        super(message);
    }

	public TicketPrintingException(String string, IOException e) {
		super(string,e);
	}
}
