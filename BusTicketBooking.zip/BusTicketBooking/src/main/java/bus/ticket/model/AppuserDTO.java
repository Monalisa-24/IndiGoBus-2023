package bus.ticket.model;

import javax.validation.constraints.*;

public class AppuserDTO {
	  	@NotNull
	    private Long appuserid;
	  	@NotNull
	  	@Size(min=3, max=15, message="Username must be minimun 3 character and maximum 15character.")
	    private String username;
	  	@NotNull
	  	@Size(min=8, max=13, message="Password range must be 8 to 13 character.")
	    private String password;
	  	@NotNull
	    private String email;
	    
	    
		public Long getUserid() {
			return appuserid;
		}
		public void setUserId(Long appuserid) {
			this.appuserid = appuserid;
		}
		
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		
		
		@Override
		public String toString() {
			return "AppuserDTO[userId=" + appuserid + ", username=" + username +", password=" + password +  ", email=" + email+ "]";
		}
		
//		
}
