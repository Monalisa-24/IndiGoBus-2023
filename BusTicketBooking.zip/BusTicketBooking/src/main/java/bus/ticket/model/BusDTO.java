package bus.ticket.model;

import javax.validation.constraints.*;

import bus.ticket.entities.Route;
import bus.ticket.entities.Schedule;


public class BusDTO {
	@NotNull
	private Long busid;
	@NotNull
	private String busName;
	@NotNull
	private Route route;
	@NotNull
    private Schedule schedule;
	private int totalSeats = 5;  // Default total seats for every bus
    private int leftSeats = totalSeats;
    
    
	public Long getBusId() {
		return busid;
	}

	public void setBusId(Long busId) {
		this.busid = busId;
	}

	
	
	public String getBusName() {
		return busName;
	}

	public void setBusName(String busName) {
		this.busName = busName;
	}

	public Route getRoute() {
		return route;
	}

	public void setRoute(Route route) {
		this.route = route;
	}

	public Schedule getSchedule() {
		return schedule;
	}

	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

	public int getTotalSeats() {
        return totalSeats;
    }

    public void setTotalSeats(int totalSeats) {
        this.totalSeats = totalSeats;
    }

    public int getLeftSeats() {
        return leftSeats;
    }

    public void setLeftSeats(int leftSeats) {
        this.leftSeats = leftSeats;
    }

    // Update left seats based on ticket booking
    public void updateLeftSeats(int bookedSeats) {
        this.leftSeats = Math.max(0, totalSeats - bookedSeats);
    }


	@Override
	public String toString() {
		return "Bus [busid=" + busid + ", busName=" + busName + ", route=" + route + ", schedule=" + schedule
				+ ", totalSeats=" + totalSeats + ", leftSeats=" + leftSeats + "]";
	}

}
