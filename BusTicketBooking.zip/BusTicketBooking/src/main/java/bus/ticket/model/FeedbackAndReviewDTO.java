package bus.ticket.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import bus.ticket.entities.Appuser;
import bus.ticket.entities.Bus;

public class FeedbackAndReviewDTO {
	@NotNull
	private Long reviewid;
	@NotNull
    private Appuser appuser;
	@NotNull
    private String reviewText;
	@NotNull
    private int rating;
    
    
	public Long getReviewId() {
		return reviewid;
	}
	public void setReviewId(Long reviewid) {
		this.reviewid = reviewid;
	}
	public Appuser getAppuser() {
		return appuser;
	}
	public void setAppuser(Appuser appuser) {
		this.appuser = appuser;
	}
	public String getReviewText() {
		return reviewText;
	}
	public void setReviewText(String reviewText) {
		this.reviewText = reviewText;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "FeedbackAndReviewDTO [reviewId=" + reviewid + ", appuser=" + appuser + ", reviewText="
				+ reviewText + ", rating=" + rating + "]";
	}

}
