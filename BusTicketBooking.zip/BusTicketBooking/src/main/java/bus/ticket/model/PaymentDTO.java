package bus.ticket.model;

import java.sql.Timestamp;

import javax.validation.constraints.NotNull;

import bus.ticket.entities.Appuser;
import bus.ticket.entities.Ticket;

public class PaymentDTO {
	@NotNull
	private Long paymentid;
	@NotNull
    private Appuser appuser;
	@NotNull
	private Ticket ticket;
	@NotNull
    private double amount;
	@NotNull
    private Timestamp timestamp;
    
    
	public Long getPaymentid() {
		return paymentid;
	}
	public void setPaymentid(Long paymentid) {
		this.paymentid = paymentid;
	}
	public Appuser getAppuser() {
		return appuser;
	}
	public void setAppuser(Appuser appuser) {
		this.appuser = appuser;
	}
	public Ticket getTicket() {
		return ticket;
	}
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Timestamp getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}
	@Override
	public String toString() {
		return "PaymentDTO [paymentid=" + paymentid + ", appuser=" + appuser + ", amount=" + amount + ", timestamp="+ timestamp + "]";
	}

}
