package bus.ticket.model;

import javax.validation.constraints.NotNull;

public class RouteDTO {
	@NotNull
	private Long routeid;
	@NotNull
	private String routeName;
	@NotNull
    private String origin;
	@NotNull
    private String destination;
    
	public String getRouteName() {
		return routeName;
	}

	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}

	public void setRouteid(Long routeid) {
		this.routeid = routeid;
	}

	public Long getRouteid() {
		return routeid;
	}
	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}


	@Override
	public String toString() {
		return "RouteDTO [routeid=" + routeid + ", routeName=" + routeName + ", origin=" + origin + ", destination="
				+ destination + "]";
	}

}
