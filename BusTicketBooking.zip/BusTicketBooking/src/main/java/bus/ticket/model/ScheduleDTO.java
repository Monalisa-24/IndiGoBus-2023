package bus.ticket.model;

import java.time.LocalDateTime;
import java.time.LocalTime;

import javax.validation.constraints.NotNull;

public class ScheduleDTO {
	@NotNull
	private Long scheduleid;
	@NotNull
	private String scheduleName;
	@NotNull
    private LocalTime departureTime;
	@NotNull
    private LocalTime arrivalTime;
    
	public Long getScheduleid() {
		return scheduleid;
	}

	public void setScheduleid(Long scheduleid) {
		this.scheduleid = scheduleid;
	}

	public String getScheduleName() {
		return scheduleName;
	}

	public void setScheduleName(String scheduleName) {
		this.scheduleName = scheduleName;
	}

	
	public LocalTime getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(LocalTime departureTime) {
		this.departureTime = departureTime;
	}
	public LocalTime getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(LocalTime arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	
	
	@Override
	public String toString() {
		return "Schedule [scheduleid=" + scheduleid + ", scheduleName=" + scheduleName + ", departureTime="
				+ departureTime + ", arrivalTime=" + arrivalTime + "]";
	}
}
