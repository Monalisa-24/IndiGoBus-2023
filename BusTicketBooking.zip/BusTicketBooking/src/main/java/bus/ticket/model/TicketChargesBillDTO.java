package bus.ticket.model;

import java.sql.Timestamp;


import javax.validation.constraints.*;

import bus.ticket.entities.Ticket;

public class TicketChargesBillDTO {
	@NotNull
	private Long billid;
	@NotNull
    private Ticket ticket;
	@NotNull
    private double amount;
	@NotNull
    private Timestamp timestamp;

    
    
	public Long getBillid() {
		return billid;
	}

	public void setBillid(Long billid) {
		this.billid = billid;
	}

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "TicketChargesBillDTO [billid=" + billid + ", ticket=" + ticket + ", amount=" + amount + ", timestamp="
				+ timestamp + "]";
	}

}

