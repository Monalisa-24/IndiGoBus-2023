package bus.ticket.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.validation.constraints.*;
import bus.ticket.entities.Appuser;
import bus.ticket.entities.Bus;
//import bus.ticket.entities.Seat;

public class TicketDTO {
	@NotNull
	private Long ticketid;
	@NotNull
    private Appuser appuser;
	@NotNull
    private Bus bus;
	private Timestamp bookingDate;
    private boolean isAvailable = true;
    
    public TicketDTO() {
        this.bookingDate = new Timestamp(new Date().getTime());
    }
    
	public Long getTicketid() {
		return ticketid;
	}
	public void setTicketid(Long ticketid) {
		this.ticketid = ticketid;
	}
	public Appuser getAppuser() {
		return appuser;
	}
	public void setAppuser(Appuser appuser) {
		this.appuser = appuser;
	}
	public Bus getBus() {
		return bus;
	}
	public void setBus(Bus bus) {
		this.bus = bus;
	}
	
	public Timestamp getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(Timestamp bookingDate) {
		this.bookingDate = bookingDate;
	}
	public boolean isAvailable() {
		return isAvailable;
	}
	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	@Override
	public String toString() {
		return "TicketDTO [ticketid=" + ticketid + ", appuser=" + appuser + ", bus=" + bus +  ", bookingDate=" + bookingDate + ", isAvailable=" + isAvailable + "]";
	}
}
