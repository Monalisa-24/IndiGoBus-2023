package bus.ticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import bus.ticket.entities.Appuser;

public interface AppUserRepository  extends JpaRepository<Appuser, Long>{

}
