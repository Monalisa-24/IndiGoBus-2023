package bus.ticket.repository;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import bus.ticket.entities.Bus;
import bus.ticket.entities.Route;
import bus.ticket.entities.Schedule;
import bus.ticket.model.*;

public interface BusRepository extends JpaRepository<Bus, Long> {

	@Query("SELECT b FROM Bus b WHERE b.route = :route AND b.schedule = :schedule")
    List<Bus> findByRouteAndSchedule(@Param("route") RouteDTO route, @Param("schedule") ScheduleDTO schedule);


}
