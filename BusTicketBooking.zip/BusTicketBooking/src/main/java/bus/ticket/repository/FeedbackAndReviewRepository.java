package bus.ticket.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import bus.ticket.entities.Appuser;
import bus.ticket.entities.FeedbackAndReview;

public interface FeedbackAndReviewRepository extends JpaRepository<FeedbackAndReview, Long> {
//	List<FeedbackAndReview> findTopNByOrderByReviewDateDesc(int count);
	List<FeedbackAndReview> findByAppuser(Appuser appuser);
}
