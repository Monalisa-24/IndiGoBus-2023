package bus.ticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import bus.ticket.entities.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Long> {

}
