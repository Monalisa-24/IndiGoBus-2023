package bus.ticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import bus.ticket.entities.Route;

public interface RouteRepository  extends JpaRepository<Route, Long>{

}
