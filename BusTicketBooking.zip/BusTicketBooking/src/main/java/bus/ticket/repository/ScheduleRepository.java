package bus.ticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import bus.ticket.entities.Schedule;

public interface ScheduleRepository  extends JpaRepository<Schedule, Long>{

}
