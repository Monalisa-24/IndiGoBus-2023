package bus.ticket.repository;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;

import bus.ticket.entities.Ticket;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

	int deleteByBookingDate(LocalDate yesterday);
    
}

