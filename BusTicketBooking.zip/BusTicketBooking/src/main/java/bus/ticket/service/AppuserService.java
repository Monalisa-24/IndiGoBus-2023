package bus.ticket.service;

import java.util.List;

import bus.ticket.entities.Appuser;
import bus.ticket.model.AppuserDTO;

public interface AppuserService {
	
	AppuserDTO getUserById(Long appuserid);
    List<AppuserDTO> getAllUsers();
    AppuserDTO createUser(Appuser appuser);
    AppuserDTO updateUser(Long appuserid, Appuser appuser);
    String deleteUser(Long appuserid);
    boolean verifyEmailValidOrNot(String email);
}
