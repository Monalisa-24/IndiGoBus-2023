package bus.ticket.service;

import java.util.List;

import bus.ticket.entities.Bus;
import bus.ticket.model.BusDTO;
import bus.ticket.model.RouteDTO;
import bus.ticket.model.ScheduleDTO;

public interface BusService {
	
	BusDTO getBusById(Long busid);
    List<BusDTO> getAllBuses();
    BusDTO createBus(Bus bus);
    BusDTO updateBus(Long busid, Bus bus);
    String deleteBus(Long busid);
    String assignBus(long busid, long scheduleid, long routeid);
    List<Bus> findBusesByRouteAndSchedule(RouteDTO route, ScheduleDTO schedule);
}
