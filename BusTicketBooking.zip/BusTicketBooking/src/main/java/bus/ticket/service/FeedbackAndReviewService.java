package bus.ticket.service;

import java.util.List;

import bus.ticket.entities.FeedbackAndReview;
import bus.ticket.model.FeedbackAndReviewDTO;

public interface FeedbackAndReviewService {
	
		FeedbackAndReviewDTO submitFeedbackAndReview(FeedbackAndReview review, Long appuserid);
		List<FeedbackAndReviewDTO> getAllReviews();
		List<FeedbackAndReviewDTO> getReviewsByUser(Long appuserid) throws Exception;
//		List<FeedbackAndReviewDTO> getRecentReviews(int count) throws Exception;
		String deleteReview(Long reviewId, Long appuserid);
		FeedbackAndReviewDTO updateReview(Long reviewid, FeedbackAndReview updatedReview);
	
}
