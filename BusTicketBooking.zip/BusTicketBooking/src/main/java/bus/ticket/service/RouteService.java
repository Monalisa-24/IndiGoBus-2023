package bus.ticket.service;

import java.util.List;

import bus.ticket.entities.Route;
import bus.ticket.model.RouteDTO;

public interface RouteService {

	RouteDTO getRouteById(Long routeid);
    List<RouteDTO> getAllRoutes();
    RouteDTO createRoute(Route route);
    RouteDTO updateRoute(Long routeid, Route route);
    String deleteRoute(Long routeid);
	
}
