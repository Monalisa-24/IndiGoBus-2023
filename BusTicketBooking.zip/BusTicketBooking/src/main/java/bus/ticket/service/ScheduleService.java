package bus.ticket.service;

import java.util.List;

import bus.ticket.entities.Schedule;
import bus.ticket.model.ScheduleDTO;

public interface ScheduleService {

	ScheduleDTO getScheduleById(Long scheduleid);
    List<ScheduleDTO> getAllSchedules();
    ScheduleDTO createSchedule(Schedule schedule);
    ScheduleDTO updateSchedule(Long scheduleid, Schedule schedule);
    String deleteSchedule(Long scheduleid);
	
}
