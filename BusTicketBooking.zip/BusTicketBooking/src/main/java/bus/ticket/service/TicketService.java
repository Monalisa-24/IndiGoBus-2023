package bus.ticket.service;

import bus.ticket.entities.*;
import bus.ticket.model.TicketDTO;

import java.util.*;


public interface TicketService {
	TicketDTO createTicket(Ticket ticket);
	String bookTicket(Long appuserid, Long busid, Long ticketid);
	List<TicketDTO> getAllTicketsForUser(Long appuserid);
    List<TicketDTO> getAllTicketsForBus(Long busid);
    void cancelTicket(Long ticketId);
    byte[] printTicket(Long ticketId);
    List<TicketDTO> getAllTickets();
    TicketDTO getTicketById(Long ticketid);
}
