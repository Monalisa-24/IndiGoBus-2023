package bus.ticket.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.*;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


import bus.ticket.exception.ResourceNotFoundException;
import bus.ticket.entities.*;
import bus.ticket.model.*;
import bus.ticket.repository.*;
import bus.ticket.service.*;
import bus.ticket.util.Converter;

import org.springframework.stereotype.Service;
@Service
public class AppuserServiceImpl implements AppuserService {

	@Autowired
	AppUserRepository userrepository;
	@Autowired
	Converter con;
	
	private static final String EMAIL_REGEX =
            "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$";
	
	
	@Override
	public AppuserDTO getUserById(Long appuserid) {
		Appuser existingUser = userrepository.findById(appuserid).orElseThrow(()->
		new ResourceNotFoundException("Appuser", "Id", appuserid));
		return con.convertToAppuserDTO(existingUser);
	}

	@Override
	public List<AppuserDTO> getAllUsers() {
		List<Appuser> alluser = userrepository.findAll();
		List<AppuserDTO> alluserdto = new ArrayList();
		for(Appuser i:alluser) {
			alluserdto.add(con.convertToAppuserDTO(i));
		}
		return alluserdto;
	}

	@Override
	public AppuserDTO createUser(Appuser appuser) {
		return con.convertToAppuserDTO(userrepository.save(appuser));
	}

	@Override
	public AppuserDTO updateUser(Long appuserid, Appuser appuser) {
        Appuser existingUser = userrepository.findById(appuserid).orElseThrow(()->
		new ResourceNotFoundException("Appuser", "Id", appuserid));
        if (existingUser != null) {
            existingUser.setUsername(appuser.getUsername());
            existingUser.setPassword(appuser.getPassword());
            existingUser.setEmail(appuser.getEmail());
            return  con.convertToAppuserDTO(userrepository.save(existingUser));
        }
        return null;
	}

	@Override
	public String deleteUser(Long appuserid) {
		userrepository.deleteById(appuserid);
		return "user, having "+appuserid+" has been deleted.";
	}
	
	
	@Override
    public boolean verifyEmailValidOrNot(String email) {
        Pattern pattern = Pattern.compile(EMAIL_REGEX);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

}
