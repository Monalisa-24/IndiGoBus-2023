package bus.ticket.serviceImpl;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;

import bus.ticket.exception.EntityNotFoundException;
import bus.ticket.exception.ResourceNotFoundException;
import bus.ticket.entities.*;
import bus.ticket.model.*;
import bus.ticket.repository.*;
import bus.ticket.service.*;
import bus.ticket.util.Converter;

import org.springframework.stereotype.Service;
@Service
public class BusServiceImpl implements BusService {

	@Autowired
	Converter con;
	
	@Autowired
	BusRepository busrepository;
	@Autowired
	ScheduleRepository schedulerepository; // Assume you have this repository
	@Autowired
    RouteRepository routerepository;       // Assume you have this repository

    // Constructor for dependency injection
    public BusServiceImpl(BusRepository busrepository, ScheduleRepository schedulerepository, RouteRepository routerepository) {
        this.busrepository = busrepository;
        this.schedulerepository = schedulerepository;
        this.routerepository = routerepository;
    }
	
	@Override
	public BusDTO getBusById(Long busid) {
		Bus getId = busrepository.findById(busid).orElseThrow(()->
		new ResourceNotFoundException("Bus", "Id", busid));
		return con.convertToBusDTO(getId);
	}

	@Override
	public List<BusDTO> getAllBuses() {
		List<Bus> buses = busrepository.findAll();
		List<BusDTO> busdto = new ArrayList();
		for(Bus i : buses) {
			busdto.add(con.convertToBusDTO(i));
		}
		return busdto;
	}

	@Override
	public BusDTO createBus(Bus bus) {
		return con.convertToBusDTO(busrepository.save(bus));
	}

	@Override
	public BusDTO updateBus(Long busid, Bus bus) {
		Bus getId = busrepository.findById(busid).orElseThrow(()->
		new ResourceNotFoundException("Bus", "Id", busid));
		getId.setRoute(bus.getRoute());
		getId.setSchedule(bus.getSchedule());
		return con.convertToBusDTO(getId);
	}

	@Override
	public String deleteBus(Long busid) {
		busrepository.deleteById(busid);
		return "Bus, having "+busid+"has been deleted.";
	}

	@Override
    public String assignBus(long busid, long scheduleid, long routeid) {
        Bus bus = busrepository.findById(busid).orElse(null);
        Schedule schedule = schedulerepository.findById(scheduleid).orElse(null);
        Route route = routerepository.findById(routeid).orElse(null);

        if (bus != null && schedule != null && route != null) {
            bus.setSchedule(schedule);
            bus.setRoute(route);
            busrepository.save(bus);
            return "Bus "+busid+" assigned : scheduleid : "+scheduleid+" and routeid : "+routeid;
        } else {
            throw new EntityNotFoundException("One or more entities not found.");
        }
    }

	@Override
	public List<Bus> findBusesByRouteAndSchedule(RouteDTO route, ScheduleDTO schedule) {
		return busrepository.findByRouteAndSchedule(route, schedule);
	}
	
}
