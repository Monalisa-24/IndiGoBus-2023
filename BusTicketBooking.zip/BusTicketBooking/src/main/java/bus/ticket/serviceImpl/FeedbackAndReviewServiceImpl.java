package bus.ticket.serviceImpl;

import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import bus.ticket.entities.*;
import bus.ticket.exception.ResourceNotFoundException;
import bus.ticket.exception.ReviewNotFoundException;
import bus.ticket.model.*;
import bus.ticket.repository.*;
import bus.ticket.service.*;
import bus.ticket.util.Converter;

import org.springframework.stereotype.Service;
@Service
public class FeedbackAndReviewServiceImpl implements FeedbackAndReviewService {

	@Autowired
	Converter con;
	
	@Autowired
	FeedbackAndReviewRepository frrep;
	
	@Autowired
	AppUserRepository aur;

	@Override
	public FeedbackAndReviewDTO submitFeedbackAndReview(FeedbackAndReview review, Long appuserid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<FeedbackAndReviewDTO> getAllReviews() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<FeedbackAndReviewDTO> getReviewsByUser(Long appuserid) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteReview(Long reviewId, Long appuserid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FeedbackAndReviewDTO updateReview(Long reviewid, FeedbackAndReview updatedReview) {
		// TODO Auto-generated method stub
		return null;
	}

	


}
