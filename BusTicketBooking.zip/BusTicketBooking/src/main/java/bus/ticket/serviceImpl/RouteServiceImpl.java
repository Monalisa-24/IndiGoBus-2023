package bus.ticket.serviceImpl;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;

import bus.ticket.entities.Route;
import bus.ticket.exception.ResourceNotFoundException;
import bus.ticket.model.RouteDTO;
import bus.ticket.repository.RouteRepository;
import bus.ticket.service.RouteService;
import bus.ticket.util.Converter;

import org.springframework.stereotype.Service;
@Service
public class RouteServiceImpl implements RouteService {

	@Autowired
	Converter con;
	@Autowired
	RouteRepository routerepository;
	
	
	@Override
	public RouteDTO getRouteById(Long routeid) {
		Route getId = routerepository.findById(routeid).orElseThrow(()->
		new ResourceNotFoundException("Route", "Id", routeid));
		return con.convertToRouteDTO(getId);
	}

	@Override
	public List<RouteDTO> getAllRoutes() {
		List<Route> routes = routerepository.findAll();
		List<RouteDTO> routesdto = new ArrayList();
		for(Route i:routes) {
			routesdto.add(con.convertToRouteDTO(i));
		}
		return routesdto;
	}

	@Override
	public RouteDTO createRoute(Route route) {
		return con.convertToRouteDTO(routerepository.save(route));
	}

	@Override
	public RouteDTO updateRoute(Long routeid, Route route) {
		Route getId = routerepository.findById(routeid).orElseThrow(()->
		new ResourceNotFoundException("Route", "Id", routeid));
		getId.setOrigin(route.getOrigin());
		getId.setDestination(route.getDestination());
		return con.convertToRouteDTO(getId);
	}

	@Override
	public String deleteRoute(Long routeid) {
		routerepository.deleteById(routeid);
		return "Route, having "+routeid+" has been deleted.";

	}

}
