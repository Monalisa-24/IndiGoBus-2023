package bus.ticket.serviceImpl;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;

import bus.ticket.entities.Schedule;
import bus.ticket.exception.ResourceNotFoundException;
import bus.ticket.model.ScheduleDTO;
import bus.ticket.repository.ScheduleRepository;
import bus.ticket.service.ScheduleService;
import bus.ticket.util.Converter;

import org.springframework.stereotype.Service;
@Service
public class ScheduleServiceImpl implements ScheduleService {


	@Autowired
	Converter con;
	@Autowired
	ScheduleRepository sr;
	
	
	@Override
	public ScheduleDTO getScheduleById(Long scheduleid) {
		Schedule getId = sr.findById(scheduleid).orElseThrow(()->
		new ResourceNotFoundException("Schedule", "Id", scheduleid));
		return con.convertToScheduleDTO(getId);
	}

	@Override
	public List<ScheduleDTO> getAllSchedules() {
		List<Schedule> schedules = sr.findAll();
		List<ScheduleDTO> schedulesdto = new ArrayList();
		for(Schedule i:schedules) {
			schedulesdto.add(con.convertToScheduleDTO(i));
		}
		return schedulesdto;
	}

	@Override
	public ScheduleDTO createSchedule(Schedule schedule) {
		return con.convertToScheduleDTO(sr.save(schedule));
	}

	@Override
	public ScheduleDTO updateSchedule(Long scheduleid, Schedule schedule) {
		Schedule getId = sr.findById(scheduleid).orElseThrow(()->
		new ResourceNotFoundException("Schedule", "Id", scheduleid));
		getId.setArrivalTime(schedule.getArrivalTime());
		getId.setDepartureTime(schedule.getDepartureTime());
		return con.convertToScheduleDTO(getId);
	}

	@Override
	public String deleteSchedule(Long scheduleid) {
		sr.deleteById(scheduleid);
		return "Schedule, having "+scheduleid+" has been deleted.";
	}

}
