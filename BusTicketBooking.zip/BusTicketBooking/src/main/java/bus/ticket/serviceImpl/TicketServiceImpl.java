package bus.ticket.serviceImpl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bus.ticket.entities.Appuser;
import bus.ticket.entities.Bus;
import bus.ticket.entities.Ticket;
import bus.ticket.exception.EntityNotFoundException;
import bus.ticket.exception.ResourceNotFoundException;
import bus.ticket.exception.TicketNotFoundException;
import bus.ticket.exception.TicketPrintingException;
import bus.ticket.model.BusDTO;
import bus.ticket.model.TicketDTO;
import bus.ticket.repository.*;
import bus.ticket.service.*;
import bus.ticket.util.Converter;

@Service
public class TicketServiceImpl implements TicketService{

	@Autowired
    private TicketRepository ticketRepository;
	@Autowired
	private BusRepository busrepository;
	@Autowired
	private AppUserRepository appuserrepository;
	@Autowired
	Converter con;
	
	@Override
	public String bookTicket(Long appuserid, Long busid, Long ticketid) {
		Bus bus = busrepository.findById(busid).orElse(null);
		Appuser appuser = appuserrepository.findById(appuserid).orElse(null);
		Ticket ticket = ticketRepository.findById(ticketid).orElse(null);
		
		if (bus != null && appuser != null && ticket != null) {
           ticket.setBus(bus);
            ticket.setAppuser(appuser);
           ticketRepository.save(ticket);
            return "Ticket : "+ticketid+" of Bus : "+busid+" Booked By : "+appuserid;
        } else {
            throw new EntityNotFoundException("One or more entities not found.");
        }
    }

    
	@Override
	public void cancelTicket(Long ticketId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public byte[] printTicket(Long ticketId) {
//		Ticket ticket = ticketRepository.findById(ticketId).orElse(null);
//
//        if (ticket == null) {
//            throw new TicketNotFoundException("Ticket with ID " + ticketId + " not found.");
//        }
//
//        // Create a PDF document for the ticket
//        try (PDDocument document = new PDDocument()) {
//            PDPage page = new PDPage(PDRectangle.A4);
//            document.addPage(page);
//
//            // Set up the content stream for drawing on the page
//            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
//                // Customize the appearance of the ticket
//                contentStream.setFont(PDType1Font.HELVETICA_BOLD, 14);
//                contentStream.newLineAtOffset(100, 700);
//
//                // Add ticket details to the PDF
//                contentStream.showText("Ticket ID: " + ticket.getTicketid());
//                contentStream.newLine();
//                contentStream.showText("User: " + ticket.getAppuser().getUsername());
//                contentStream.newLine();
//                contentStream.showText("Bus: " + ticket.getBus().getBusName());
//                contentStream.newLine();
//                contentStream.showText("Booking Date: " + ticket.getBookingDate());
//            }
//
//            // Save the PDF content to a byte array
//            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//            document.save(byteArrayOutputStream);
//            document.close();
//
//            return byteArrayOutputStream.toByteArray();
//        } catch (IOException e) {
//            throw new TicketPrintingException("Failed to generate the ticket PDF.", e);
//        }
	return null;
	}
	

	@Override
	public TicketDTO createTicket(Ticket ticket) {
		return con.convertToTicketDTO(ticketRepository.save(ticket));
	}


	@Override
	public List<TicketDTO> getAllTicketsForUser(Long appuserid) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<TicketDTO> getAllTicketsForBus(Long busid) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<TicketDTO> getAllTickets() {
		List<Ticket> tickets = ticketRepository.findAll();
		List<TicketDTO> ticketdto = new ArrayList();
		for(Ticket i : tickets) {
			ticketdto.add(con.convertToTicketDTO(i));
		}
		return ticketdto;
	}


	@Override
	public TicketDTO getTicketById(Long ticketid) {
		Ticket getId = ticketRepository.findById(ticketid).orElseThrow(()->
		new ResourceNotFoundException("Ticket", "Id", ticketid));
		return con.convertToTicketDTO(getId);
	}

}
