package bus.ticket.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.*;

import bus.ticket.entities.Appuser;
import bus.ticket.entities.Bus;
import bus.ticket.entities.FeedbackAndReview;
import bus.ticket.entities.Payment;
import bus.ticket.entities.Route;
import bus.ticket.entities.Schedule;
//import bus.ticket.entities.Seat;
import bus.ticket.entities.Ticket;
//import bus.ticket.entities.TicketChargesBill;
import bus.ticket.model.TicketChargesBillDTO;
import bus.ticket.model.AppuserDTO;
import bus.ticket.model.BusDTO;
import bus.ticket.model.FeedbackAndReviewDTO;
import bus.ticket.model.PaymentDTO;
import bus.ticket.model.RouteDTO;
import bus.ticket.model.ScheduleDTO;
//import bus.ticket.model.SeatDTO;
import bus.ticket.model.TicketDTO;


@Component
public class Converter {
	
	
	// APPUSER
	
	public Appuser convertToAppuserEntity(AppuserDTO appuserdto) {
			
			Appuser u = new Appuser();
			if(appuserdto!=null) {
				BeanUtils.copyProperties(appuserdto, u);
			}
			return u;
		}
	

	public AppuserDTO convertToAppuserDTO(Appuser appuser) {
		AppuserDTO udto=new AppuserDTO();
		if(appuser!=null) {
			BeanUtils.copyProperties(appuser, udto);
		}
		return udto;
	}
	
	
	// BUS
	
	public Bus convertToBusEntity(BusDTO busdto) {
		Bus b = new Bus();
		if(busdto!=null) {
			BeanUtils.copyProperties(busdto, b);
		}
		return b;
	}

	public BusDTO convertToBusDTO(Bus bus) {
		BusDTO bdto=new BusDTO();
		if(bus!=null) {
			BeanUtils.copyProperties(bus, bdto);
		}
		return bdto;
	}
	
	
	// ROUTE
	
	public Route convertToRouteEntity(RouteDTO routedto) {
	    Route r = new Route();
	    if (routedto != null) {
	        BeanUtils.copyProperties(routedto, r);
	    }
	    return r;
	}

	public RouteDTO convertToRouteDTO(Route route) {
	    RouteDTO rdto = new RouteDTO();
	    if (route != null) {
	        BeanUtils.copyProperties(route, rdto);
	    }
	    return rdto;
	}
	
	
	// SCHEDULE
	
	public Schedule convertToScheduleEntity(ScheduleDTO scheduledto) {
	    Schedule s = new Schedule();
	    if (scheduledto != null) {
	        BeanUtils.copyProperties(scheduledto, s);
	    }
	    return s;
	}

	public ScheduleDTO convertToScheduleDTO(Schedule schedule) {
	    ScheduleDTO sdto = new ScheduleDTO();
	    if (schedule != null) {
	        BeanUtils.copyProperties(schedule, sdto);
	    }
	    return sdto;
	}
	
	// PAYMENT
	
	public Payment convertToPaymentEntity(PaymentDTO paymentDto) {
	    Payment p = new Payment();
	    if (paymentDto != null) {
	        BeanUtils.copyProperties(paymentDto, p);
	    }
	    return p;
	}

	public PaymentDTO convertToPaymentDTO(Payment payment) {
	    PaymentDTO pdto = new PaymentDTO();
	    if (payment != null) {
	        BeanUtils.copyProperties(payment, pdto);
	    }
	    return pdto;
	}

	
	// FEEDBACK & REVIEW
	
	
	public FeedbackAndReview convertToFeedbackAndReviewEntity(FeedbackAndReviewDTO feedbackAndReviewDTO) {
	    FeedbackAndReview feedbackAndReview = new FeedbackAndReview();
	    if (feedbackAndReviewDTO != null) {
	        BeanUtils.copyProperties(feedbackAndReviewDTO, feedbackAndReview);
	    }
	    return feedbackAndReview;
	}

	public FeedbackAndReviewDTO convertToFeedbackAndReviewDTO(FeedbackAndReview feedbackAndReview) {
	    FeedbackAndReviewDTO feedbackAndReviewDTO = new FeedbackAndReviewDTO();
	    if (feedbackAndReview != null) {
	        BeanUtils.copyProperties(feedbackAndReview, feedbackAndReviewDTO);
	    }
	    return feedbackAndReviewDTO;
	}

	
	// TICKET
	
	public Ticket convertToTicketEntity(TicketDTO ticketDto) {
	    Ticket ticket = new Ticket();
	    if (ticketDto != null) {
	        BeanUtils.copyProperties(ticketDto, ticket);
	    }
	    return ticket;
	}

	public TicketDTO convertToTicketDTO(Ticket ticket) {
	    TicketDTO ticketDto = new TicketDTO();
	    if (ticket != null) {
	        BeanUtils.copyProperties(ticket, ticketDto);
	    }
	    return ticketDto;
	}


	
}
